import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { AccountcreateComponent } from './accountcreate/accountcreate.component';
import { AccountupdateComponent } from './accountupdate/accountupdate.component';
import { AccountlistComponent } from './accountlist/accountlist.component';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet,AccountlistComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'bankproject';
}
